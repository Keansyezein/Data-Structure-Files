package dentistappointment;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class DataMethods{
    
    public static void resetInput(JTextField TextField1, JTextField TextField2, JComboBox jComboBox1, JCheckBox jCheckBox1, JCheckBox jCheckBox2, JCheckBox jCheckBox3, JCheckBox jCheckBox4,
        JRadioButton JRadioButton1, JRadioButton JRadioButton2, JRadioButton JRadioButton3, JRadioButton JRadioButton4, JRadioButton JRadioButton5,
        JLabel jLabelPrice, JLabel jLabelTotalBill, JTabbedPane JTabbedPane1){
        
         // --- TEXTFIELDS 1st Tab ---
    TextField1.setText("");
    TextField2.setText("");
    
    
    // ----- ComboBox 2nd Tab ---- this is Day Selection
    jComboBox1.setSelectedIndex(0);
    

    // --- CHECKBOXES 2nd Tab ---
    jCheckBox1.setSelected(false);
    jCheckBox2.setSelected(false);
    jCheckBox3.setSelected(false);
    jCheckBox4.setSelected(false);
    
    JRadioButton1.setSelected(false);
    JRadioButton2.setSelected(false);
    JRadioButton3.setSelected(false);
    JRadioButton4.setSelected(false);
    JRadioButton5.setSelected(false);

    

    // --- LABELS (billing labels, etc.) ---
    jLabelPrice.setText("0");
    jLabelTotalBill.setText("0");
    
    JTabbedPane1.setEnabledAt(1, false);
    JTabbedPane1.setEnabledAt(2, false);                                                                                
    }
    
    
    public static void exportdata(String Client_name, String Contact_Number, 
            String Day, String Month, String Year, String Time, 
            String Service_type, String Total_bill, String dir){ //dir = "data" or "Archive"
        
        LocalDate now = LocalDate.now();
        String dir_files = "src/" + dir + "/" + now.getMonthValue() + "-" 
                + now.getDayOfMonth() + "-" + now.getYear() + ", " 
                + Client_name + ".txt";
        
        File folder = new File("src/" + dir);
        if(!folder.exists()){
            folder.mkdir();
        }
        
        try(BufferedWriter bw = new BufferedWriter(new FileWriter(dir_files))){
        bw.write(Client_name);
        bw.newLine();
        bw.write(Contact_Number);
        bw.newLine();
        bw.write(Day);
        bw.newLine();
        bw.write(Month);
        bw.newLine();
        bw.write(Year);
        bw.newLine();
        bw.write(Time);
        bw.newLine();
        bw.write(Service_type);
        bw.newLine();
        bw.write(Total_bill);
        bw.close();
        }catch(IOException e){
            e.printStackTrace();
        }
    }
    
    public static void Managedeleterecord(int row,  ArrayList<records> Arch_data, String opt){
            records rec = Arch_data.get(row);
        String dir = "";
        if (opt.equalsIgnoreCase("2") || opt.equalsIgnoreCase("0")) {
            dir = "Archives";
        }
        if (opt.equalsIgnoreCase("1")) {
            dir = "data";
        }
        
        File file = new File("src/" + dir + "/");
            File[] checknames = file.listFiles();
            if (checknames != null) {
                for (File f : checknames) {
                    try (BufferedReader br = new BufferedReader(new FileReader(f))) {
                        String Name = br.readLine();
                        String Contact = br.readLine();
                        String Day = br.readLine();
                        String Month = br.readLine();
                        String Year = br.readLine();
                        String Time = br.readLine();
                        String Type = br.readLine();
                        String Total_bill = br.readLine();

                        if (Name.equals(rec.getClient_name()) && Contact.equals(rec.getContact_Number())
                                && Day.equals(rec.getDay_of_Month()) && Month.equals(rec.getMonth())
                                && Year.equals(rec.getYear()) && Time.equals(rec.getTime())
                                && Type.equals(rec.getService_type()) && Total_bill.equals(rec.getTotal_bill())) {
                                br.close();
                                if (opt.equalsIgnoreCase("1")){
                                    DataMethods.exportdata(rec.getClient_name(), rec.getContact_Number(), rec.getDay_of_Month(), rec.getMonth(), rec.getYear(), rec.getTime(), rec.getService_type(), rec.getTotal_bill(), "Archives");  // Overwrite File
                                }
                                if (opt.equalsIgnoreCase("2")){
                                    DataMethods.exportdata(rec.getClient_name(), rec.getContact_Number(), rec.getDay_of_Month(), rec.getMonth(), rec.getYear(), rec.getTime(), rec.getService_type(), rec.getTotal_bill(), "data");  // Overwrite File
                                    JOptionPane.showMessageDialog(null, "Restored successfully");
                                    f.delete();
                                    return;
                                }
                                
                                if (f.delete()) {
                                JOptionPane.showMessageDialog(null, "File deleted successfully");

                                return;
                                } else {
                                JOptionPane.showMessageDialog(null, "Failed to delete the file");
                            }
                            
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
            
    }
        
    
    public static void InitializedData(ArrayList<records> DataRecord, String opt){
        // 1 = read archive, 2 = read data
        DataRecord.clear();
        String dir ="";
        if(opt.equals("1")){
            dir = "Archives";
        }
        if(opt.equals("2")){
            dir = "data";
        }
        
        File folder = new File("src/" + dir + "/");
        File[] ListofFiles = folder.listFiles();
        
        if(ListofFiles != null){
           for(File file : ListofFiles){
               if(file.isFile()){
                   try (BufferedReader br = new BufferedReader(new FileReader(file))) {
                   String Name = br.readLine();
                   String Contact = br.readLine();
                   String Day = br.readLine();
                   String Month = br.readLine();
                   String Year = br.readLine();
                   String Time = br.readLine();
                   String Type = br.readLine();
                   String Total_bill = br.readLine();
                   
                   DataRecord.add(new records(Name, Contact, Day, Month, Year, Time, Type, Total_bill));
                   
               }
                   catch(IOException e){
                       e.printStackTrace();
                   }
               }
               
           }
        }
        
    }
    
    
    public static void viewTable(JTable jTable1, ArrayList<records> DataRecord){
        // Get table model
    DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
    
    jTable1.setDefaultEditor(Object.class, null);
    // Clear existing rows first
    model.setRowCount(0);
    
    // Loop through your ArrayList
    for(records r : DataRecord) {
        model.addRow(new Object[]{
            r.getClient_name(),
            r.getContact_Number(),
            r.getService_type(),
            r.getTime(),
            r.getTotal_bill(),
            r.getFormatDate()
        });
    }
        
    }
    

    
    
    
    public static void Billing(String type, JLabel ServiceFee, JLabel AdditionalFee, JLabel TotalBill,
        JLabel Bill_Label1, JLabel Bill_Label2, JLabel Bill_Label3, String name, String date) {
        Map<String, Integer> pricelist = new HashMap();
        pricelist.put("Cleaning", 50);
        pricelist.put("Braces", 100);
        pricelist.put("Tooth removal", 200);
        pricelist.put("Check up", 300);
        
         if(pricelist.containsKey(type)){
             int service = pricelist.get(type);
             int additional = Integer.parseInt(AdditionalFee.getText());
        
             int total = service + additional;
             
             Bill_Label1.setText(name);
             Bill_Label2.setText(type);
             Bill_Label3.setText(date);
             ServiceFee.setText(String.valueOf(service));
             TotalBill.setText(String.valueOf(total));
             
         }
         
    }
    
        public static void if_info_filled(JTextField Client_name, JTextField Contact_number, JButton Button1){
            String name = Client_name.getText();
            String contact = Contact_number.getText();
            
            boolean validContact = contact.matches("^09\\d{9}$");

            Button1.setEnabled(!name.isEmpty() && validContact);
        }
    
    
        public static void checkingdate(JRadioButton Time_1, JRadioButton Time_2, 
                JRadioButton Time_3, JRadioButton Time_4, JRadioButton Time_5,
                String selectday, JLabel Month, JLabel Year, 
                ArrayList<records> DataRecords ){
            // reset enabled
            Time_1.setEnabled(true);
            Time_2.setEnabled(true);
            Time_3.setEnabled(true);
            Time_4.setEnabled(true);
            Time_5.setEnabled(true);


            // start disabled the same time
            for(records r: DataRecords){
                if(r.getMonth().equalsIgnoreCase(Month.getText()) 
                && r.getDay_of_Month().equalsIgnoreCase(selectday)
                && r.getYear().equalsIgnoreCase(Year.getText())){

                    if(r.getTime().equals(Time_1.getText())){
                        Time_1.setSelected(false);
                        Time_1.setEnabled(false);
                    }
                    if(r.getTime().equals(Time_2.getText())){
                        Time_2.setSelected(false);
                        Time_2.setEnabled(false);
                    }
                    if(r.getTime().equals(Time_3.getText())){
                        Time_3.setSelected(false);
                        Time_3.setEnabled(false);
                    }
                    if(r.getTime().equals(Time_4.getText())){
                        Time_4.setSelected(false);
                        Time_4.setEnabled(false);
                    }
                    if(r.getTime().equals(Time_5.getText())){
                        Time_5.setSelected(false);
                        Time_5.setEnabled(false);
                    }

                }  

            }
        }
    // RadioButton Methods
    public static void ifselected(JRadioButton select, JRadioButton other2, JRadioButton other3, JRadioButton other4, JRadioButton other5){
        if(select.isSelected()){
            other2.setSelected(false);
            other3.setSelected(false);
            other4.setSelected(false);
            other5.setSelected(false);
        }
    }
    // CheckBox Methods
    public static void ifchecked(JCheckBox select, JCheckBox other2, JCheckBox other3, JCheckBox other4){
        if(select.isSelected()){
            other2.setSelected(false);
            other3.setSelected(false);
            other4.setSelected(false);
        }
    }
    
    public static void ifschedule_done(JCheckBox Type1, JCheckBox Type2, JCheckBox Type3, JCheckBox Type4,
                                       JRadioButton Time1, JRadioButton Time2, JRadioButton Time3, JRadioButton Time4, JRadioButton Time5,
                                       JButton Button2){
         boolean serviceSelected =
        Type1.isSelected() || 
        Type2.isSelected() ||
        Type3.isSelected() ||
        Type4.isSelected();

    boolean timeSelected =
        Time1.isSelected() ||
        Time2.isSelected() ||
        Time3.isSelected() ||
        Time4.isSelected() ||
        Time5.isSelected();

    // Enable button only if BOTH are selected
    if(serviceSelected && timeSelected){
        Button2.setEnabled(true);
    } else {
        Button2.setEnabled(false);
    }
    }
    
    
    
}

//Class records - mga requirement nato i type bago i store sa arrays
class records{
    private String Client_name;
    private String Contact_Number;
    private String Day_of_Month;
    private String Month;
    private String Year;
    private String Time;
    private String Service_type;
    private String Total_bill;
    private String FormatDate;
    
    public records(String Client_name, String Contact_Number, String Day_of_Month, String Month, String Year, String Time, String Service_type, String Total_bill){
        this.Client_name = Client_name;
        this.Contact_Number = Contact_Number;
        this.Day_of_Month = Day_of_Month;
        this.Month = Month;
        this.Year = Year;
        this.Time = Time;
        this.Service_type = Service_type;
        this.Total_bill = Total_bill;
        
        this.FormatDate = Month + "/" + Day_of_Month + "/" + Year;
    }
    
    public String getClient_name(){return Client_name; }
    public String getContact_Number(){return Contact_Number; }
    public String getDay_of_Month(){return Day_of_Month; }
    public String getMonth(){return Month; }
    public String getYear(){return Year; }
    public String getTime(){return Time; }
    public String getService_type(){return Service_type; }
    public String getTotal_bill(){return Total_bill; }
    public String getFormatDate() { return FormatDate; }
    
    public void setClient_name(String NewClient_name){
        this.Client_name = NewClient_name;
    }
    public void setContact_Number(String NewContact_Number){
        this.Contact_Number = NewContact_Number;
    }
    public void setDay_of_Month(String NewDay_of_Month){
        this.Day_of_Month = NewDay_of_Month;
    }
    public void setMonth(String NewMonth){
        this.Month = Month;
    }
    public void setYear(String NewYear){
        this.Year = Year;
    }
    public void setTime(String NewTime){
        this.Time = Time;
    }
    public void setService_type(String NewService_type){
        this.Service_type = Service_type;
    }
    public void setTotal_bill(String NewTotal_bill){
        this.Total_bill = Total_bill;
    }
    public void setFormatDate(String NewFormatday){
        this.FormatDate = NewFormatday;
    }
    
    
}
