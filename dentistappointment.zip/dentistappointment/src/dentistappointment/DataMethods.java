package dentistappointment;

import static dentistappointment.dentistappointment2.DataRecord;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class DataMethods{
    
    public static void resetInput(JTextField TextField1, JTextField TextField2, JComboBox jComboBox1, JCheckBox jCheckBox1, JCheckBox jCheckBox2, JCheckBox jCheckBox3, JCheckBox jCheckBox4,
        JRadioButton JRadioButton1, JRadioButton JRadioButton2, JRadioButton JRadioButton3, JRadioButton JRadioButton4, JRadioButton JRadioButton5,
        JLabel jLabelPrice, JLabel jLabelTotalBill, JTabbedPane JTabbedPane1){
        
         // --- TEXTFIELDS 1st Tab ---
    TextField1.setText("");
    TextField2.setText("");
    
    
    // ----- ComboBox 2nd Tab ---- this is Day Selection
    jComboBox1.setSelectedIndex(0);
    

    // --- CHECKBOXES 2nd Tab ---
    jCheckBox1.setSelected(false);
    jCheckBox2.setSelected(false);
    jCheckBox3.setSelected(false);
    jCheckBox4.setSelected(false);
    
    JRadioButton1.setSelected(false);
    JRadioButton2.setSelected(false);
    JRadioButton3.setSelected(false);
    JRadioButton4.setSelected(false);
    JRadioButton5.setSelected(false);

    

    // --- LABELS (billing labels, etc.) ---
    jLabelPrice.setText("0");
    jLabelTotalBill.setText("");
    
    JTabbedPane1.setEnabledAt(1, false);
    JTabbedPane1.setEnabledAt(2, false);
    }
    
    
    public static void viewTable(JTable jTable1, ArrayList<records> DataRecord){
        // Get table model
    DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
    
    // Clear existing rows first
    model.setRowCount(0);
    
    // Loop through your ArrayList
    for(records r : DataRecord) {
        model.addRow(new Object[]{
            r.getClient_name(),
            r.getContact_Number(),
            r.getService_type(),
            r.getTime(),
            r.getTotal_bill(),
            r.getFormatDate()
        });
    }
        
    }
    
    
    
    
    public static void Billing(String type, JLabel ServiceFee, JLabel AdditionalFee, JLabel TotalBill) {
        Map<String, Integer> pricelist = new HashMap();
        pricelist.put("Cleaning", 50);
        pricelist.put("Braces", 100);
        pricelist.put("Tooth removal", 200);
        pricelist.put("Check up", 300);
        
         if(pricelist.containsKey(type)){
             
             int service = pricelist.get(type);
             int additional = Integer.parseInt(AdditionalFee.getText());
        
             int total = service + additional;
        
             ServiceFee.setText(String.valueOf(service));
             TotalBill.setText(String.valueOf(total));
         }
         
    }
    
    
    public static void checkingdate(JRadioButton Time_1, JRadioButton Time_2, JRadioButton Time_3, JRadioButton Time_4, JRadioButton Time_5,
            String selectday, JLabel Month, JLabel Year){
        // reset enabled
        Time_1.setEnabled(true);
        Time_2.setEnabled(true);
        Time_3.setEnabled(true);
        Time_4.setEnabled(true);
        Time_5.setEnabled(true);
        
        
        // start disabled the same time
        for(records r: DataRecord){
            if(r.getMonth().equalsIgnoreCase(Month.getText()) 
            && r.getDay_of_Month().equals(selectday)
            && r.getYear().equals(Year.getText())){
                
                if(r.getTime().equals(Time_1.getText())){
                    Time_1.setSelected(false);
                    Time_1.setEnabled(false);
                }
                if(r.getTime().equals(Time_2.getText())){
                    Time_2.setSelected(false);
                    Time_2.setEnabled(false);
                }
                if(r.getTime().equals(Time_3.getText())){
                    Time_3.setSelected(false);
                    Time_3.setEnabled(false);
                }
                if(r.getTime().equals(Time_4.getText())){
                    Time_4.setSelected(false);
                    Time_4.setEnabled(false);
                }
                if(r.getTime().equals(Time_5.getText())){
                    Time_5.setSelected(false);
                    Time_5.setEnabled(false);
                }
                
            }
            else{   
                    // if Both time are Available
                    Time_1.setEnabled(true);
                    Time_2.setEnabled(true);
                    Time_3.setEnabled(true);
                    Time_4.setEnabled(true);
                    Time_5.setEnabled(true);
            }
        }
    }
    // RadioButton Methods
    public static void ifselected(JRadioButton select, JRadioButton other2, JRadioButton other3, JRadioButton other4, JRadioButton other5){
        if(select.isSelected()){
            other2.setSelected(false);
            other3.setSelected(false);
            other4.setSelected(false);
            other5.setSelected(false);
        }
    }
    // CheckBox Methods
    public static void ifchecked(JCheckBox select, JCheckBox other2, JCheckBox other3, JCheckBox other4){
        if(select.isSelected()){
            other2.setSelected(false);
            other3.setSelected(false);
            other4.setSelected(false);
        }
    }
    
    public static void ifschedule_done(JCheckBox Type1, JCheckBox Type2, JCheckBox Type3, JCheckBox Type4,
                                       JRadioButton Time1, JRadioButton Time2, JRadioButton Time3, JRadioButton Time4, JRadioButton Time5,
                                       JButton Button2){
         boolean serviceSelected =
        Type1.isSelected() ||
        Type2.isSelected() ||
        Type3.isSelected() ||
        Type4.isSelected();

    boolean timeSelected =
        Time1.isSelected() ||
        Time2.isSelected() ||
        Time3.isSelected() ||
        Time4.isSelected() ||
        Time5.isSelected();

    // Enable button only if BOTH are selected
    if(serviceSelected && timeSelected){
        Button2.setEnabled(true);
    } else {
        Button2.setEnabled(false);
    }
    }
    
}

//Class records - mga requirement nato i type bago i store sa arrays
class records{
    private String Client_name;
    private String Contact_Number;
    private String Day_of_Month;
    private String Month;
    private String Year;
    private String Time;
    private String Service_type;
    private String Total_bill;
    private String FormatDate;
    
    public records(String Client_name, String Contact_Number, String Day_of_Month, String Month, String Year, String Time, String Service_type, String Total_bill){
        this.Client_name = Client_name;
        this.Contact_Number = Contact_Number;
        this.Day_of_Month = Day_of_Month;
        this.Month = Month;
        this.Year = Year;
        this.Time = Time;
        this.Service_type = Service_type;
        this.Total_bill = Total_bill;
        
        this.FormatDate = Month + "/" + Day_of_Month + "/" + Year;
    }
    
    public String getClient_name(){return Client_name; }
    public String getContact_Number(){return Contact_Number; }
    public String getDay_of_Month(){return Day_of_Month; }
    public String getMonth(){return Month; }
    public String getYear(){return Year; }
    public String getTime(){return Time; }
    public String getService_type(){return Service_type; }
    public String getTotal_bill(){return Total_bill; }
    public String getFormatDate() { return FormatDate; }
    
        
    
    
}
