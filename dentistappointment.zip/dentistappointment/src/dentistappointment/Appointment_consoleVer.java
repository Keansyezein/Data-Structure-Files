package dentistappointment;


import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;

public class Appointment_consoleVer {

    static ArrayList<DentistData> DataList = new ArrayList();

    public static void main(String args[]) {
        boolean run = false;
        while (!run) {
            Scanner sc = new Scanner(System.in);
            LocalDate today = LocalDate.now();
            String todays_month = Integer.toString(today.getMonthValue());
            String todays_year = Integer.toString(today.getYear());

            System.out.println(" - - Dentist Appointment System - - ");
            System.out.println("1. Appointment");
            System.out.println("2. View");
            System.out.println("3. exit");
            System.out.print("Input:");
            String opt = sc.nextLine();
            
            switch (opt) {
                case "1":
                    System.out.print("Enter Dentist Name:");
                    String Dentist_name = sc.nextLine();

                    System.out.print("Enter Client Name:");
                    String Client_name = sc.nextLine();

                    System.out.println("Month and Year Autofilled at " + today.getMonth().name() + ", " + todays_year);
                    System.out.print("Enter the day of " + today.getMonth().name() + ": ");
                    String date_of_day = sc.nextLine();

                    System.out.println("At what time? (12-hour format)");
                    System.out.print("Enter hour (1 - 12): ");
                    int hour = sc.nextInt();

                    System.out.print("Enter minutes (00 or 30): ");
                    int minute = sc.nextInt();
                    sc.nextLine(); // consume leftover newline

                    System.out.print("AM or PM: ");
                    String am_pm = sc.nextLine().toUpperCase();

                    String time = hour + ":" + minute + " " + am_pm;
                    System.out.println("\nTime entered: " + time);

                    boolean exists = false;

                    for (DentistData d : DataList) {
                        if (d.getDate_of_day().equals(date_of_day)
                                && d.getDate_of_month().equals(todays_month)
                                && d.getDate_of_year().equals(todays_year)
                                && d.gettime().equals(time)) {

                            System.out.println("\n Appointment conflict detected!");
                            System.out.println("That slot is already taken by Dr. " + d.getDentist_Name()
                                    + " and client " + d.getClient_Name() + ".");
                            exists = true;
                            break;
                        }
                    }

                    if (!exists) {
                        DentistData newData = new DentistData(Dentist_name, Client_name, date_of_day, todays_month, todays_year, time);
                        DataList.add(newData);
                        System.out.println("\n Appointment added successfully!");
                    }
                    break;
                    
                case "2":
                    for(DentistData D: DataList){
                        System.out.println("===============================================");
                        System.out.println("Dentist Name: " + D.getDentist_Name() 
                                + "\nClient Name: " + D.getClient_Name() 
                                + "\nDate: " + D.getDate() 
                                + "\nTime: " + D.gettime());
                    }
                    break;
                
                case "3":
                    run = true;
                    break;
            }

        }

    }

}

class DentistData {

    private String Dentist_Name;
    private String Client_Name;
    private String Date_of_day;
    private String Date_of_month;
    private String Date_of_year;
    private String time;

    public DentistData(String Dentist_Name, String Client_Name, String Date_of_day, String Date_of_month, String Date_of_year, String time) {
        this.Dentist_Name = Dentist_Name;
        this.Client_Name = Client_Name;
        this.Date_of_day = Date_of_day;
        this.Date_of_month = Date_of_month;
        this.Date_of_year = Date_of_year;
        this.time = time;
    }

    public String getDentist_Name() {
        return Dentist_Name;
    }

    public String getClient_Name() {
        return Client_Name;
    }

    public String getDate_of_day() {
        return Date_of_day;
    }

    public String getDate_of_month() {
        return Date_of_month;
    }

    public String getDate_of_year() {
        return Date_of_year;
    }
    public String getDate(){
        return Date_of_day + "/" + Date_of_month + "/" + Date_of_year;
    }

    public String gettime() {
        return time;
    }
}
