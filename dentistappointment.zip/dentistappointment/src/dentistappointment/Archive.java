
package dentistappointment;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class Archive extends javax.swing.JFrame {

    public Archive() {
        initComponents();
   
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        viewArchiveBtn = new javax.swing.JButton();
        PermanentDlt = new javax.swing.JButton();
        RestoreBtn = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Client Name", "Contact Number", "Service Type", "Time", "Bill", "Date"
            }
        ));
        jScrollPane1.setViewportView(jTable2);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 576, 308));

        viewArchiveBtn.setText("View Archive");
        viewArchiveBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                viewArchiveBtnActionPerformed(evt);
            }
        });
        getContentPane().add(viewArchiveBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 320, -1, -1));

        PermanentDlt.setText("Permanent Delete");
        PermanentDlt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PermanentDltActionPerformed(evt);
            }
        });
        getContentPane().add(PermanentDlt, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 320, -1, -1));

        RestoreBtn.setText("Restore");
        RestoreBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RestoreBtnActionPerformed(evt);
            }
        });
        getContentPane().add(RestoreBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 320, -1, -1));

        setSize(new java.awt.Dimension(592, 399));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void viewArchiveBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_viewArchiveBtnActionPerformed
        DataMethods.InitializedData(dentistappointment.Archive, "1");  // 1 = archive, 2 = data, empty = equivalent to data
        DataMethods.viewTable(jTable2, dentistappointment.Archive);
    }//GEN-LAST:event_viewArchiveBtnActionPerformed

    private void PermanentDltActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PermanentDltActionPerformed
        int row = jTable2.getSelectedRow();
        
        if (row == -1) {
        JOptionPane.showMessageDialog(this, "Please select a cell to edit.");
        return;
    }
        DataMethods.Managedeleterecord(row, dentistappointment.Archive, "0"); // 1 means put to archive, if 2, put to data, if not either of them, permanent delete
    }//GEN-LAST:event_PermanentDltActionPerformed

    private void RestoreBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RestoreBtnActionPerformed
        int row = jTable2.getSelectedRow();
        
        if (row == -1) {
        JOptionPane.showMessageDialog(this, "Please select a cell to edit.");
        return;
    }
        DataMethods.Managedeleterecord(row, dentistappointment.Archive, "2"); // 1 means put to archive, if 2, put to data, if 0, permanent delete
    }//GEN-LAST:event_RestoreBtnActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Archive().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton PermanentDlt;
    private javax.swing.JButton RestoreBtn;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable2;
    private javax.swing.JButton viewArchiveBtn;
    // End of variables declaration//GEN-END:variables
}
