package dentistappointment;

import static dentistappointment.dentistappointment.DataRecord;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import javax.swing.JOptionPane;


public class re_edit extends javax.swing.JFrame {

    int rowIndex;
    int colIndex;
    int opt;
    public re_edit(int rowIndex,int colIndex, String oldvalue) {
        initComponents();
        this.rowIndex = rowIndex;
        this.colIndex = colIndex;
        jTextField.setText(oldvalue);
        opt = colIndex;
    }
    
    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jTextField = new javax.swing.JTextField();
        ConfirmBtn = new javax.swing.JButton();
        CancelBtn = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(333, 141));

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setText("Type here:");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(28, 14, -1, -1));

        jTextField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTextFieldKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTextFieldKeyTyped(evt);
            }
        });
        jPanel1.add(jTextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(28, 36, 276, 48));

        ConfirmBtn.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        ConfirmBtn.setText("Confirm");
        ConfirmBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ConfirmBtnActionPerformed(evt);
            }
        });
        jPanel1.add(ConfirmBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 100, 90, 40));

        CancelBtn.setBackground(new java.awt.Color(153, 0, 51));
        CancelBtn.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        CancelBtn.setForeground(new java.awt.Color(255, 255, 255));
        CancelBtn.setText("Cancel");
        CancelBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CancelBtnActionPerformed(evt);
            }
        });
        jPanel1.add(CancelBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 100, 90, 40));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 340, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void ConfirmBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ConfirmBtnActionPerformed
        String newValue = jTextField.getText();

    int confirm = JOptionPane.showConfirmDialog(
        this,
        "Are you sure you want to update this value?",
        "Confirm Edit",
        JOptionPane.YES_NO_OPTION
    );

    if (confirm == JOptionPane.YES_OPTION) {
        applyUpdate(newValue);
        DataMethods.InitializedData(DataRecord, "2"); // 1 = archive, 2 = data
        this.dispose();
    }
    }//GEN-LAST:event_ConfirmBtnActionPerformed

    private void CancelBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CancelBtnActionPerformed
        this.dispose();
    }//GEN-LAST:event_CancelBtnActionPerformed

    private void jTextFieldKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextFieldKeyTyped
        
         if(opt == 0){
                char c = evt.getKeyChar();
        if(Character.isDigit(c)) {  // if non digit, and exceed to 11 digit will not be typed
            evt.consume();
        }
        
         }
         if(opt == 1){
          
        char c = evt.getKeyChar();
        if(jTextField.getText().length() > 10 || !Character.isDigit(c)) {  // if non digit, and exceed to 11 digit will not be typed
            evt.consume();
        }
         }
        
        
    }//GEN-LAST:event_jTextFieldKeyTyped

    private void jTextFieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextFieldKeyReleased
         if(opt == 0){
           if(!jTextField.getText().isEmpty()){
               ConfirmBtn.setEnabled(true);
           }
           else{
               ConfirmBtn.setEnabled(false);
           }
           
         }
         if(opt == 1){
           if(jTextField.getText().matches("^09\\d{9}$")){
              ConfirmBtn.setEnabled(true);
           }
           else{
               ConfirmBtn.setEnabled(false);
           }
         }

    }//GEN-LAST:event_jTextFieldKeyReleased

    public void applyUpdate(String newValue){
         records rec = DataRecord.get(rowIndex);

    switch (colIndex) {
        case 0 :
            // Specify the file path
            File file = new File("src/data/");
            File[] checknames = file.listFiles();
            if (checknames != null) {
                for (File f : checknames) {
                    try (BufferedReader br = new BufferedReader(new FileReader(f))) {
                        String Name = br.readLine();
                        String Contact = br.readLine();
                        String Day = br.readLine();
                        String Month = br.readLine();
                        String Year = br.readLine();
                        String Time = br.readLine();
                        String Type = br.readLine();
                        String Total_bill = br.readLine();

                        if (Name.equals(rec.getClient_name()) && Contact.equals(rec.getContact_Number())
                                && Day.equals(rec.getDay_of_Month()) && Month.equals(rec.getMonth())
                                && Year.equals(rec.getYear()) && Time.equals(rec.getTime())
                                && Type.equals(rec.getService_type()) && Total_bill.equals(rec.getTotal_bill())) {
                                br.close();
                                if (f.delete()) {
                                JOptionPane.showMessageDialog(this, "File deleted successfully");
                                DataMethods.exportdata(newValue, rec.getContact_Number(), rec.getDay_of_Month(),
                                    rec.getMonth(), rec.getYear(), rec.getTime(), rec.getService_type(), 
                                    rec.getTotal_bill(), "data");  // Overwrite File
                               
                                return;
                                } else {
                                JOptionPane.showMessageDialog(this, "Failed to delete the file");
                            }
                            
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }

            break;
        case 1 : 
            DataMethods.exportdata(rec.getClient_name(), newValue, rec.getDay_of_Month(), rec.getMonth(), rec.getYear(), rec.getTime(), rec.getService_type(), rec.getTotal_bill(), "data"); // new Contact_number
        break;
    }
    
    
}
    
   
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton CancelBtn;
    private javax.swing.JButton ConfirmBtn;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField jTextField;
    // End of variables declaration//GEN-END:variables

}
